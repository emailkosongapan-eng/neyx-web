# NEYX DATABASE

Deployable login + dashboard connected to the GitHub Contents API.

## GitHub database
- Owner: `emailkosongapan-eng`
- Repo: `neyx-database`
- Branch: `main`
- Token DB: `database/token.json`
- User DB: `database/users.json`

## Environment variables

Set these on your hosting provider:

```env
GITHUB_TOKEN=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
JWT_SECRET=APANGANTENGBANGET
PORT=3000

GITHUB_OWNER=emailkosongapan-eng
GITHUB_REPO=neyx-database
GITHUB_BRANCH=main

CREATOR_USERNAME=apanzxc
CREATOR_PASSWORD=akujelek12
```

`CREATOR_USERNAME` and `CREATOR_PASSWORD` are only used to bootstrap the creator account when `database/users.json` is empty/missing.

## GitHub token permissions

Use a fine-grained GitHub token with access to this repository and permission to read/write repository contents.

## Run locally

```bash
npm install
npm start
```

Open `http://localhost:3000`.

## Role limits

- reseller: 6 addtoken
- partner: 8 addtoken
- moderator: 10 addtoken
- owner: 15 addtoken
- creator: unlimited addtoken + adduser

The limit is enforced server-side, not by the browser.
