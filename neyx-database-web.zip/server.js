const express = require("express");
const cookieParser = require("cookie-parser");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const app = express();
app.use(express.json({ limit: "32kb" }));
app.use(cookieParser());
app.use(express.static("public"));

const PORT = process.env.PORT || 3000;
const GH_TOKEN = process.env.GITHUB_TOKEN;
const GH_OWNER = process.env.GITHUB_OWNER || "emailkosongapan-eng";
const GH_REPO = process.env.GITHUB_REPO || "neyx-database";
const GH_BRANCH = process.env.GITHUB_BRANCH || "main";
const JWT_SECRET = process.env.JWT_SECRET;

const TOKEN_PATH = "database/token.json";
const USER_PATH = "database/users.json";

const LIMITS = {
  reseller: 6,
  partner: 8,
  moderator: 10,
  owner: 15,
  creator: Infinity
};

if (!GH_TOKEN || !JWT_SECRET) {
  console.error("Missing GITHUB_TOKEN or JWT_SECRET");
  process.exit(1);
}

function apiUrl(path) {
  return `https://api.github.com/repos/${GH_OWNER}/${GH_REPO}/contents/${path}`;
}

async function github(path, options = {}) {
  const response = await fetch(apiUrl(path), {
    ...options,
    headers: {
      "Accept": "application/vnd.github+json",
      "Authorization": `Bearer ${GH_TOKEN}`,
      "X-GitHub-Api-Version": "2022-11-28",
      "Content-Type": "application/json",
      ...(options.headers || {})
    }
  });

  const text = await response.text();
  let data;
  try { data = JSON.parse(text); } catch { data = { message: text }; }

  if (!response.ok) {
    const err = new Error(data.message || `GitHub API ${response.status}`);
    err.status = response.status;
    throw err;
  }
  return data;
}

async function readJson(path, fallback) {
  try {
    const file = await github(path);
    const decoded = Buffer.from(file.content, "base64").toString("utf8");
    return { data: JSON.parse(decoded), sha: file.sha };
  } catch (e) {
    if (e.status === 404) return { data: fallback, sha: null };
    throw e;
  }
}

async function writeJson(path, value, sha, message) {
  const content = Buffer.from(JSON.stringify(value, null, 2) + "\n").toString("base64");
  const body = { message, content, branch: GH_BRANCH };
  if (sha) body.sha = sha;
  return github(path, { method: "PUT", body: JSON.stringify(body) });
}

async function ensureCreator() {
  const result = await readJson(USER_PATH, { users: [] });
  if (!Array.isArray(result.data.users)) result.data = { users: [] };

  if (result.data.users.length === 0) {
    const username = process.env.CREATOR_USERNAME;
    const password = process.env.CREATOR_PASSWORD;
    if (!username || !password) {
      throw new Error("database/users.json is empty and CREATOR_USERNAME/CREATOR_PASSWORD are missing");
    }

    const passwordHash = await bcrypt.hash(password, 12);
    result.data.users.push({
      username,
      passwordHash,
      role: "creator",
      createdAt: new Date().toISOString()
    });

    await writeJson(USER_PATH, result.data, result.sha, "Initialize creator account");
  }
}

function sign(user) {
  return jwt.sign(
    { username: user.username, role: user.role },
    JWT_SECRET,
    { expiresIn: "12h" }
  );
}

function auth(req, res, next) {
  try {
    const token = req.cookies.session;
    if (!token) return res.status(401).json({ error: "Not authenticated" });
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: "Session expired" });
  }
}

app.get("/api/me", auth, async (req, res) => {
  try {
    const tokens = await readJson(TOKEN_PATH, { tokens: [] });
    const users = await readJson(USER_PATH, { users: [] });

    const list = Array.isArray(tokens.data.tokens) ? tokens.data.tokens : [];
    const allUsers = Array.isArray(users.data.users) ? users.data.users : [];
    const limit = LIMITS[req.user.role];

    res.json({
      user: req.user,
      tokenCount: list.length,
      userCount: allUsers.length,
      limit: limit === Infinity ? null : limit,
      canAddUser: req.user.role === "creator"
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post("/api/login", async (req, res) => {
  try {
    const username = String(req.body.username || "").trim();
    const password = String(req.body.password || "");

    if (!username || !password) {
      return res.status(400).json({ error: "Username dan password wajib diisi" });
    }

    const result = await readJson(USER_PATH, { users: [] });
    const user = result.data.users.find(
      u => String(u.username).toLowerCase() === username.toLowerCase()
    );

    if (!user || !user.passwordHash || !(await bcrypt.compare(password, user.passwordHash))) {
      return res.status(401).json({ error: "Username atau password salah" });
    }

    if (!LIMITS.hasOwnProperty(user.role)) {
      return res.status(500).json({ error: "Role akun tidak valid" });
    }

    res.cookie("session", sign(user), {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      maxAge: 12 * 60 * 60 * 1000
    });

    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post("/api/logout", (req, res) => {
  res.clearCookie("session");
  res.json({ ok: true });
});

app.post("/api/addtoken", auth, async (req, res) => {
  try {
    const token = String(req.body.token || "").trim();
    if (!token) return res.status(400).json({ error: "Token wajib diisi" });

    const limit = LIMITS[req.user.role];
    const result = await readJson(TOKEN_PATH, { tokens: [] });
    if (!Array.isArray(result.data.tokens)) result.data.tokens = [];

    if (limit !== Infinity && result.data.tokens.length >= limit) {
      return res.status(403).json({ error: `Limit role ${req.user.role} adalah ${limit} token` });
    }

    if (result.data.tokens.includes(token)) {
      return res.status(409).json({ error: "Token sudah ada di database" });
    }

    result.data.tokens.push(token);
    await writeJson(
      TOKEN_PATH,
      result.data,
      result.sha,
      `Add token by ${req.user.username}`
    );

    res.json({ ok: true, tokenCount: result.data.tokens.length });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post("/api/adduser", auth, async (req, res) => {
  try {
    if (req.user.role !== "creator") {
      return res.status(403).json({ error: "Hanya creator yang bisa menambahkan user" });
    }

    const username = String(req.body.username || "").trim();
    const password = String(req.body.password || "");
    const role = String(req.body.role || "").toLowerCase();

    if (!username || password.length < 6 || !LIMITS.hasOwnProperty(role)) {
      return res.status(400).json({
        error: "Username wajib diisi, password minimal 6 karakter, dan role harus valid"
      });
    }

    const result = await readJson(USER_PATH, { users: [] });
    if (!Array.isArray(result.data.users)) result.data.users = [];

    if (result.data.users.some(u => u.username.toLowerCase() === username.toLowerCase())) {
      return res.status(409).json({ error: "Username sudah digunakan" });
    }

    result.data.users.push({
      username,
      passwordHash: await bcrypt.hash(password, 12),
      role,
      createdAt: new Date().toISOString()
    });

    await writeJson(
      USER_PATH,
      result.data,
      result.sha,
      `Add user ${username} by ${req.user.username}`
    );

    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get("/api/users", auth, async (req, res) => {
  try {
    const result = await readJson(USER_PATH, { users: [] });
    res.json({
      users: result.data.users.map(u => ({
        username: u.username,
        role: u.role,
        createdAt: u.createdAt
      }))
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

(async () => {
  try {
    await ensureCreator();
    app.listen(PORT, () => console.log(`NEYX DATABASE running on port ${PORT}`));
  } catch (e) {
    console.error("Startup error:", e.message);
    process.exit(1);
  }
})();
